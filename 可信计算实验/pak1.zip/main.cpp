

//// ����������
//#include <iostream>
//#include <fstream>
//#include <string>
//#include <sha.h>
//#include <hex.h>
//
//using namespace CryptoPP;
//using namespace std;
//
//// �����ļ��Ĺ�ϣֵ
//string computeFileHash(const string& filename) {
//    SHA256 hash;
//    string digest;
//
//    ifstream file(filename, ios::binary);
//    if (!file) {
//        cerr << "�޷����ļ���" << filename << endl;
//        exit(1);
//    }
//
//    string contents((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
//    StringSource ss(contents, true,
//        new HashFilter(hash,
//            new HexEncoder(
//                new StringSink(digest), false)));
//
//    return digest;
//}
//
//// �����ַ������ļ��Ĺ�ϣֵ
//string computeHash(const string& data, const string& filename) {
//    SHA256 hash;
//    string digest;
//
//    ifstream file(filename, ios::binary);
//    if (!file) {
//        cerr << "�޷����ļ���" << filename << endl;
//        exit(1);
//    }
//
//    string contents((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
//    string combined = data + contents;
//
//    StringSource ss(combined, true,
//        new HashFilter(hash,
//            new HexEncoder(
//                new StringSink(digest), false)));
//
//    return digest;
//}
//
//int main() {
//    // ����H4
//    string H4 = computeFileHash("EXE1.exe");
//
//    // ����H3
//    string H3 = computeHash(H4, "file3.txt");
//
//    // ����H2
//    string H2 = computeHash(H3, "file2.txt");
//
//    // ����H1
//    string H1 = computeHash(H2, "file1.txt");
//
//    // ����ϣֵ���浽�ļ�
//    ofstream hashFile("hashes.txt");
//    if (!hashFile) {
//        cerr << "�޷�������ϣ�ļ�" << endl;
//        exit(1);
//    }
//
//    hashFile << H1 << endl;
//    hashFile << H2 << endl;
//    hashFile << H3 << endl;
//    hashFile << H4 << endl;
//
//    cout << "������������ɣ���ϣֵ�ѱ��档" << endl;
//
//    return 0;
//}


// ��������֤
#include <iostream>
#include <fstream>
#include <string>
#include <sha.h>
#include <hex.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <unistd.h>
#endif

using namespace CryptoPP;
using namespace std;

// �����ļ��Ĺ�ϣֵ
string computeFileHash(const string& filename) {
    SHA256 hash;
    string digest;

    ifstream file(filename, ios::binary);
    if (!file) {
        cerr << "�޷����ļ���" << filename << endl;
        exit(1);
    }

    string contents((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
    StringSource ss(contents, true,
        new HashFilter(hash,
            new HexEncoder(
                new StringSink(digest), false)));

    return digest;
}

// �����ַ������ļ��Ĺ�ϣֵ
string computeHash(const string& data, const string& filename) {
    SHA256 hash;
    string digest;

    ifstream file(filename, ios::binary);
    if (!file) {
        cerr << "�޷����ļ���" << filename << endl;
        exit(1);
    }

    string contents((istreambuf_iterator<char>(file)), istreambuf_iterator<char>());
    string combined = data + contents;

    StringSource ss(combined, true,
        new HashFilter(hash,
            new HexEncoder(
                new StringSink(digest), false)));

    return digest;
}

int main() {
    // ��ȡԤ��Ĺ�ϣֵ
    ifstream hashFile("hashes.txt");
    if (!hashFile) {
        cerr << "�޷��򿪹�ϣ�ļ�" << endl;
        exit(1);
    }

    string storedH1, storedH2, storedH3, storedH4;
    getline(hashFile, storedH1);
    getline(hashFile, storedH2);
    getline(hashFile, storedH3);
    getline(hashFile, storedH4);

    // ��֤H1
    string computedH2 = computeHash(storedH2, "file1.txt");
    if (computedH2 != storedH1) {
        cerr << "H1��֤ʧ�ܣ�" << endl;
        exit(1);
    }

    // ��֤H2
    string computedH3 = computeHash(storedH3, "file2.txt");
    if (computedH3 != storedH2) {
        cerr << "H2��֤ʧ�ܣ�" << endl;
        exit(1);
    }

    // ��֤H3
    string computedH4 = computeHash(storedH4, "file3.txt");
    if (computedH4 != storedH3) {
        cerr << "H3��֤ʧ�ܣ�" << endl;
        exit(1);
    }

    // ��֤H4
    string computedH4Final = computeFileHash("EXE1.exe");
    if (computedH4Final != storedH4) {
        cerr << "E1��֤ʧ�ܣ�" << endl;
        //system("EXE2.exe");
        exit(1);
    }

    cout << "��������֤�ɹ�����������Ӧ�ó���..." << endl;

    // ����Ӧ�ó���file4.txt��Ϊ��ִ���ļ���
#ifdef _WIN32
    system("EXE1.exe");
#else
    system("./file4");
#endif

    return 0;
}
